This directory contains the necessary vagrant files to create a VM with Tuxedo installed.

1) To use, download the following files from Oracle to ~/Downloads:
	tuxedo121300_64_Linux_01_x86.zip	Tuxedo 12.1.3 installer for Linux 64bit
	p19927652_121300_Linux-x86-64.zip	Latest Tuxedo patch kit (file name may be different)

2) Download and unzip the tuxedo_vagrant.zip file

3) Execute vagrant up


	
