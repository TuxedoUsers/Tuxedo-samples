Please place in this folder the following files from OTN:

tuxedo121300_64_Linux_01_x86.zip
bankapp.zip

And place the following file(s) in this folder from My Oracle Support:

p19927652_121300_Linux-x86-64.zip
