For Tuxedo 12.1.3, please place the following files from OTN in this directory:

tuxedo121300_64_Linux_01_x86.zip
bankapp.zip

And place the following file from My Oracle Support in this directory:

p19927652_121300_Linux-x86-64.zip or any other Tuxedo 12.1.3 rolling patch installer




For Tuxedo 12.1.1, please place the following files from OTN in this directory:

tuxedo12110_64_linux_5_x86.bin
bankapp.zip

And place the following file(s) in this folder from My Oracle Support:

p20103223_121100_Linux-x86-64.zip or any other Tuxedo 12.1.1 rolling patch installer


