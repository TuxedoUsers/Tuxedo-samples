# Tuxedo bankapp sample application
This folder contains the files necessary to fix up the copy of the bankapp application that is on OTN to work in this environment.
